#!/bin/sh
/bin/sed -i '/admin ALL=(ALL) ALL/d' /etc/sudoers
